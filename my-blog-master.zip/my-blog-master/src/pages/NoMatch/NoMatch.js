import React from 'react'

export const NoMatch = () => {
  return (
    <h1>Page not found</h1>
  )
}
