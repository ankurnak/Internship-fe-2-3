const Homepage = () => {
    return (
        <div>
            <h1>Get started with React-Router 6</h1>
        </div>
    )
}

export {Homepage}
